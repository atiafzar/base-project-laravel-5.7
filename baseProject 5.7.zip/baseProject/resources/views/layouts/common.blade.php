{{--
for use bootstrap v 3.3.7 enable belowe code
--}}

{{--<link href="{{asset('css/bootstrap-3.3.7.css')}}" rel="stylesheet" type="text/css">
<script src="{{asset('js/bootstrap-3.3.7.min.js')}}"></script>--}}



<script src="{{asset('js/jquery-3.3.1.min.js')}}"></script>